//public class Interpreter {
//    Parser parser;
//    AST astAfterParser;
//
//    public Interpreter(Parser p){
//        parser = p;
//        astAfterParser = p.parse();
//        System.out.println("After parser:"+astAfterParser.toString());
//    }
//
//    private  boolean isAbstraction(AST ast){
//        return ast instanceof Abstraction;
//    }
//    private  boolean isApplication(AST ast){
//        return ast instanceof Application;
//    }
//    private  boolean isIdentifier(AST ast){
//        return ast instanceof Identifier;
//    }
//
//    public AST eval(){
//        return evalAST(astAfterParser);
//    }
//
//
//    private  AST evalAST(AST ast){
//        //TODO
//        return null;
//    }
//
//    private AST substitute(AST node,AST value){
//        return shift(-1,subst(node,shift(1,value,0),0),0);
//    }
//
//    private AST subst(AST node, AST value, int depth){
//        //TODO
//        return null;
//    }
//
//    private AST shift(int by, AST node,int from){
//       //TODO
//        return null;
//    }
//}




public class Interpreter {
    Parser parser;
    AST astAfterParser;

    private AST result;
    private StringBuilder builder = new StringBuilder();

    public Interpreter(Parser p){
        parser = p;
        astAfterParser = p.parse();
        System.out.println("After parser:"+astAfterParser.toString());
    }

    private  boolean isAbstraction(AST ast){
        return ast instanceof Abstraction;
    }
    private  boolean isApplication(AST ast){
        return ast instanceof Application;
    }
    private  boolean isIdentifier(AST ast){
        return ast instanceof Identifier;
    }

    public AST eval(){
        return evalAST(astAfterParser);
    }


    private  AST evalAST(AST ast){
        while (true) {
            builder.append("now is eval: " + ast.toString() + "\n");
            if (ast instanceof Application) {
                if (isAbstraction(((Application) ast).getLhs())) {
                    builder.append("now is substitute "+"node: "+
                            ((Application) ast).getLhs().toString()+
                            "  value: "+((Application) ast).getRhs().toString()+"\n");

                    ast = substitute(((Abstraction)((Application) ast).getLhs()).body,((Application) ast).getRhs());
                } else if(isApplication(((Application) ast).getLhs())&&!isIdentifier(((Application) ast).getRhs())){
                    ((Application) ast).setLhs(evalAST(((Application) ast).getLhs()));
                    ((Application) ast).setRhs(evalAST(((Application) ast).getRhs()));
                    if(isAbstraction(((Application) ast).getLhs())) ast = evalAST(ast);
                    return ast;
                } else if(isApplication(((Application) ast).getLhs())&&isIdentifier(((Application) ast).getRhs())){
                    ((Application) ast).setLhs(evalAST(((Application) ast).getLhs()));
                    if(isAbstraction(((Application) ast).getLhs())) ast = evalAST(ast);
                    return ast;
                } else{
                    ((Application) ast).setRhs(evalAST(((Application) ast).getRhs()));
                    return ast;
                }
            } else if (isAbstraction(ast)) {
                ((Abstraction) ast).body = evalAST(((Abstraction) ast).body);
                return ast;
            }else {
                return ast;
            }
        }
    }

    private AST substitute(AST node,AST value){
        return shift(-1,subst(node,shift(1,value,0),0),0);
    }

    private AST subst(AST node, AST value, int depth){
        if (isApplication(node)) {
            return new Application(subst(((Application) node).getLhs(), value, depth),subst(((Application) node).getRhs(), value, depth));
        } else if (isAbstraction(node)) {
            return new Abstraction(((Abstraction) node).param,subst(((Abstraction) node).body,value,depth+1));
        }else {
            if(depth==((Identifier)node).getDBindex()) {
                builder.append("subst: "+"from "+node.toString()+" ("+node.toString()+") "+" to "+value.toString()+"\n");
                return shift(depth,value,0);
            }
            else return node;
        }
    }

    private AST shift(int by, AST node,int from){
        builder.append("now is shift: "+node.toString()+"\n");
        if(isApplication(node)){
            return new Application(shift(by,((Application)(node)).getLhs(),from), shift(by,((Application)(node)).getRhs(),from));
        }
        else if(isAbstraction(node)){
            return new Abstraction(((Abstraction) node).param,shift(by,((Abstraction) node).body,from+1));
        }
        else{
            Identifier identifier = new Identifier(((Identifier) node).name, String.valueOf(((Identifier) node).getDBindex() + (((Identifier) node).getDBindex() >= from ? by : 0)));
            builder.append("shift(by: "+by+" from: "+from+"): "+"lambda: "+node.toString()+" De Bruijn: "+node.toString()+" to "+identifier.toString()+"\n");
            return identifier;

        }
    }
}